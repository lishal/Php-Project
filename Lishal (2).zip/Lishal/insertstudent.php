<?php
require("dbconnect.php");
if(isset($_POST['submit'])){

$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$uname=$_POST['username']; 
$pwd=$_POST['password'];
$contact=$_POST['contact'];
$address=$_POST['address']; 
$ctype=$_POST['ctype'];
$gender=$_POST['gender'];
$photo=$_POST['photo'];

 $sqll="INSERT INTO balak (firstname,lastname,Uname,Pwd,Contact,Address,Course_Type,Gender,Photo) VALUES ('$fname','$lname','$uname','$pwd','$contact','$address','$ctype','$gender','$photo')";



if (mysqli_query($connectivity,$sqll)) {
	
	header("refresh:1; url=admin.php");

}
else{
echo "Sorry your Data is not added";

}
}

?>