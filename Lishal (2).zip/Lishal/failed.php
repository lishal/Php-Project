<?php
echo"Sorry the username you are trying to give is already in our data.Please try new username";
?>

	<title>Failed!</title>
<button  name="back">	<a href="mainlogin.php" style="text-decoration: none;">Back To Login Page
</button>