<form method="POST" action="studentpwchange.php">
Current Password:<input type="password" placeholder="Enter Current Password" name="cpwd"><br><br>
New Password:<input type="password" placeholder="Enter New Password" name="npwd"><br><Br>
Confirm New Password:<input type="password" placeholder="Enter New Password" name="cnpwd"><br><br>

<input type="Submit" name="Submit">
</form>

<?php
session_start();
require("dbconnect.php");



if (isset($_POST['Submit']))
{
	$password=$_REQUEST['cpwd'];
	$npassword=$_REQUEST['npwd'];
	$cnpassword=$_REQUEST['cnpwd'];
	$user=$_SESSION['user'];

	if($_SESSION['pwd']==$password)
	{ 

		if($npassword==$cnpassword){
			$sql="UPDATE balak SET Pwd='$cnpassword' where Uname='$user'";
			$res=mysqli_query($connectivity,$sql);
			echo"Your Password is successfully changed!";
		}
		else{
			echo"Please check your new password again";
		}
	}

	else{
		echo"Your Current Password is wrong";
	}

}
?>
<br>
<br>
<button><a href="mainlogin.php">Back to Login</a></button>