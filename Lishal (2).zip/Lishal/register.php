<?php
require("dbconnect.php");
	if(isset($_POST['signup']))
		{

			$Fname=$_POST['Fname'];
			$Lname=$_POST['Lname'];
			$Uname=$_POST['Username'];
			$Password=$_POST['pwd'];
			$Number=$_REQUEST['Number'];
			$Address=$_POST['Address'];
			$Salary=$_POST['Salary'];
			$Department=$_POST['Department'];
			$Gender=$_REQUEST['Gender'];
			$Photo=$_POST['Photo'];

			 $sql="INSERT INTO teacher (firstname,lastname,username,password,Contact,Address,Salary,Department,Gender,Photo) VALUES ('$Fname','$Lname','$Uname','$Password','$Number','$Address','$Salary','$Department','$Gender','$Photo')";


			if (!mysqli_query($connectivity,$sql))
			{
				header("location:failed.php");
				exit();
				
			}
			else
			{
				header("location:successfull.php");
				exit();
			}
		}


?>



<!DOCTYPE html>
<html>
<head>
	<title>Teacher |Register</title>
	<style type="text/css">
		body{
	background: url(register.jpg) no-repeat;
	background-size: 100%;
	margin:0px;
	padding: 0px; 
}
.frame{
	position: absolute;
  top: 4%;
  left: 25%;
  width: 800px;
  height: 704px;
  padding: 10px 20px;
  box-sizing: border-box;
  color:black; 
  background: rgba(0,0,0,.5);
  border: black 1px solid;
}
.form input[type="text"]
{
  border: none;
  border-bottom:1px solid #fff;
  background: transparent;
  outline: none;
  height: 20px;
  color: #ffffff;
  font-size: 16px;
  border-radius: 0px;
}
.form input
{
  width: 40%;
  padding: 10px;
  margin-right: 45px;
  margin-bottom: 20px;
}
.container input{
	width :40%;
	margin-right: 45px;
	padding:10px;
}
.container input[type="text"],
.container input[type="password"]
{
  border: none;
  border-bottom:1px solid #fff;
  background: transparent;
  outline: none;
  height: 20px;
  color: #ffffff;
  font-size: 16px;
  border-radius: 0px;
}
.container p
{
  margin-top: -17px;
  font-size:20px; 
  margin-left: 380px;
  margin-bottom: 20px;
  padding: 02px;
  color:#ffffff;
}
.number input{
  width :40%;
  margin-right: 45px;
  margin-top: 15px;
  padding:10px;
}
.number input[type="text"]{
  border: none;
  border-bottom:1px solid #fff;
  background: transparent;
  outline: none;
  height: 20px;
  color: #ffffff;
  font-size: 16px;
  border-radius: 0px;
}
.number p
{
  margin-top: -12px;
  font-size:18px; 
  margin-left: 375px;
  margin-bottom: 10px;
  padding: 02px;
  color:#ffffff;
}

.semi-final p
{
  margin-top: 10px;
  font-size:18px; 
  margin-right: 45px;
  margin-bottom:5px;
  padding: 02px;
  color:#ffffff;
}
.semi-final input{
  width :40%;
  margin-right: 45px;
  margin-top: 15px;
  padding:10px;
}
.semi-final input[type="text"]{
  border: none;
  border-bottom:1px solid #fff;
  background: transparent;
  outline: none;
  height: 20px;
  color: #ffffff;
  font-size: 16px;
  border-radius: 0px;
}
select{
	margin:0px;
	margin-top:0px;
	padding: 10px;
	background:white;
  color:black;
  border: none;
  border-bottom:1px solid #fff;
}
.final p
{
  margin-top: 20px;
  font-size:18px; 
  margin-right: 45px;
  margin-bottom:5px;
  padding: 02px;
  color:#ffffff;
}
.final input[type="Submit"]{
    margin-top: 20px;
    margin-left: 375px;
    border: none;
    outline: none;
    height: 40px;
    color:#fff;
    font-size: 16px;
    background: gold;
    border-radius: 10px;
  }
  .final input[type="Submit"]:hover{
    background:lightgreen;
  }
.final button
{
  border: none;
  outline: none;
  height: 40px;
  color:#fff;
  font-size: 16px;
  background: gold;
  border-radius: 10px;
}
.final button:hover{
  background:lightgreen;
}
.final button a{
  text-decoration: none;
  color:#fff;
}
.back {
  margin-top:3px;
  margin-left: 350px;
  border: none;
  outline: none;
  height: 40px;
  color:#fff;
  font-size: 16px;
  background: gold;
  border-radius: 10px;
}
.back a{
  text-decoration: none;
  color: white;
}
	</style>
	<meta charset="utf-8">
	<script type="text/javascript">
		function forblank(){
			var firstpwd=form.pwd.value;
			var secondpwd=form.pwd1.value;
			var a=document.getElementById('num').value;
			var b=document.getElementById('Salary').value;
			var chk=document.getElementById("chk")
			if (document.getElementById('fname').value=="") {
				alert('Please Enter Your First Name');
				return false;
			}
			else if (document.getElementById('lname').value=="") {
				alert('Please Enter Your Last Name');
				return false;
			}
			else if (document.getElementById('uname').value=="") {
				alert('Please Enter Your Username Name');
				return false;
			}
			else if(document.getElementById('pwd').value==""){
				alert('Please Enter Your password');
				return false;
			}
			else if(document.getElementById('pwd1').value==""){
				alert('Please Enter Your Conformation password');
				return false;
			}
			else if(firstpwd!=secondpwd){
				alert('Make sure that both password is same');
				return false;
			}
			else if(document.getElementById('num').value==""){
				alert('Please Enter Your Mobile number');
				return false;
			}
			else if(isNaN(a)){
				alert('Please Enter Your Mobile number in Number Format');
				return false;
			}
			else if(a.length<10){
				alert('Your Mobile number must be of 10 digits only');
				return false;
			}
			else if(a.length>10){
				alert('Your Mobile number must be of 10 digits only');
				return false;
			}
			else if(isNaN(b)){
				alert('Please Enter Your Salary number in Number Format');
				return false;
			}
			else if(a.length<10){
				alert('Your salary number must be of 10 digits only');
				return false;
			}
			else if(a.length>10){
				alert('Your salary number must be of 10 digits only');
				return false;
			}
			else if(document.getElementById('photo').value==""){
				alert('Please choose your photo');
				return false;
			}
			else if(chk.checked==false){
				alert('Make sure that you have checked Terms and Conditions');
				return false;
			}		
		}
	</script>
</head>
<body>
	<div class="frame">
		<h2>Create Your Account</h2>
		<form name="form" method="post" action="register.php" onsubmit="return forblank()">
		<div class="form">
			<input type="text" id="fname" placeholder="First name" name="Fname">
			<input type="text" id="lname" placeholder="Last name" name="Lname">
		</div>
		<div class="container">
			<input type="text" id="uname" placeholder="Username" name="Username">
			<p>For Example abc@gmail.com</p>
			<input type="password" name="pwd" id="pwd" placeholder="Enter Your password">
			<input type="password" name="pwd1" id="pwd1" placeholder="Confirm Your password">
		</div>
		<div class="number">
			<input type="text" id="num"name="Number" placeholder="Enter Your Contact Number">
			<p>For Example: 9867232568 (It should be in number)</p>
		</div>
		<div class="semi-final">
			<input type="text" name="Address" placeholder="Enter Your Address">
			<input type="text" name="Salary" id="Salary" placeholder="Enter Your Salary">
			<p>Department:</p><select name="Department"><option value="computing" name="computing">Computing</option>
			<option value="Networking" name="networking">Networking</option>
		 	<option value="Multi Media" name="multi media">Multi Media</option>
		 	<option value="Mobile App" name="mobile app">Mobile App</option>
		 </select>
		</div>
		<div class="final">
			<p>Select Your Gender</p><p>Male <input type="radio" name="Gender" checked="male" value="male"> Female <input type="radio" name="Gender" value="female"> Other <input type="radio" name="Gender"value="other"></p><br>
			<input type="file" name="Photo" id="photo"/>
			<input type="checkbox" id="chk" name="chk">Agree Terms and Condition
			<br>
			<button type="Submit"  name="signup" class="button" style="margin-left: 378px;" >Sign up</button>			
	</div>
</form>
<button class="back"><a href="mainlogin.php">Back to Sign In</a></button>
</div>
</body>
</html>
