<?php
echo"Thank You your record is successfully saved!";
?>

	<title>Successfull!</title>

	<button  name="back">	<a href="mainlogin.php" style="text-decoration: none;">Back To Login Page
</button>
