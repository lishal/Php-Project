<?php
require("dbconnect.php");
if(isset($_POST['submit'])){
$sqll = "UPDATE balak SET firstname='$_POST[firstname]' , lastname ='$_POST[lastname]', Uname = '$_POST[username]' , Pwd = '$_POST[Password]' , Contact = '$_POST[Contact]' ,Address = '$_POST[Address]' , Course_Type = '$_POST[Ctype]' ,Gender = '$_POST[Gender]' WHERE ID='$_POST[id]'";



if (mysqli_query($connectivity,$sqll)) {
	
	header("refresh:1; url=updatestudent.php");

}
else{
echo "sorry, your record is not completed";

}
}
else{
	$sqll = "DELETE FROM balak WHERE ID='$_POST[id]'";
	if (mysqli_query($connectivity,$sqll)) {
	
	header("refresh:1; url=updatestudent.php");

}
else{
echo "Sorry your record is not deleted";

}
}
?>