<body>
	<?php

		require("dbconnect.php");

	?>
	<script type="text/javascript">
		function forblank(){
			var a=document.getElementById('num').value;
			if (document.getElementById('fname').value=="") {
				alert('Please Enter Your First Name');
				return false;
			}
			else if (document.getElementById('lname').value=="") {
				alert('Please Enter Your Last Name');
				return false;
			}
			else if (document.getElementById('uname').value=="") {
				alert('Please Enter Your Username Name');
				return false;
			}
			else if(document.getElementById('pwd').value==""){
				alert('Please Enter Your password');
				return false;
			}

			else if(document.getElementById('num').value==""){
				alert('Please Enter Your Mobile number');
				return false;
			}
			else if(isNaN(a)){
				alert('Please Enter Your Mobile number in Number Format');
				return false;
			}
			else if(a.length<10){
				alert('Your Mobile number must be of 10 digits only');
				return false;
			}
			else if(a.length>10){
				alert('Your Mobile number must be of 10 digits only');
				return false;
			}
			else if(document.getElementById('add').value==""){
				alert('Please Enter Your Address');
				return false;
			}
			else if(document.getElementById('ctype').value==""){
				alert('Please Enter Your Couese Type');
				return false;
			}
			else if(document.getElementById('gender').value==""){
				alert('Please Enter Your Gender');
				return false;
			}
			else if(document.getElementById('photo').value==""){
				alert('Please Select your Image');
				return false;
			}

		}
	</script>
	<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Username</th>
			<th>Password</th>
			<th>Contact</th>
			<th>Address</th>
			<th>Course Type</th>
			<th>Gender</th>
			<th>Photo</th>
		</tr>
		<tr><form name="form" action ="insertstudent.php" method="POST" onsubmit="return forblank()></tr>
			<tr>
			<td><input type ="text" name="firstname" id="fname"></td>
			<td><input type="text" name="lastname" id="lname"></td>
			<td><input type="text" name="username" id="uname"></td>
			<td><input type="text" name="password" id="pwd"></td>
			<td><input type="text" name="contact" id="num"></td>
			<td><input type="text" name="address"id="add"></td>
			<td><input type="text" name="ctype" id="ctype"></td>
			<td><input type="text" name="gender" id="gender"></td>
			<td><input type="file" name="photo" id="photo"></td>
			<td><input type="Submit" name="submit" value="Add Record"></td>
		</tr>
		

		</form>

	</table>
		<br>
	<Br>
	<button><a href="admin.php" style="text-decoration: none;">Back to Admin page </a></button>