<h1 align="center"> Records Of Teachers </h1>
<style type="text/css">
table{
	border-collapse: collapse;
	width: 85%;
	color: blue;
	font-family: monospace;
	font-size: 25px;
	text-align: center; 
}
	
</style>
<table>

	<?php
require("dbconnect.php");

$sqll="SELECT * FROM teacher";
$res=mysqli_query($connectivity,$sqll);

if ($res->num_rows > 0){
			echo "<tr><th>ID</th><th>Firstname</th><th>Last Name</th><th>Username</th><th>Password</th><th>Contact</th><th>Address</th><th>Salary</th><th>Department</th><th>Gender</th></tr>";

while($ro=mysqli_fetch_assoc($res)){


	echo "<tr><td>".$ro['ID']."</td><td>".$ro['firstname']."</td><td>".$ro['lastname']."</td><td>".$ro['username']."</td><td>".$ro['password']."</td><td>".$ro['Contact']."</td><td>".$ro['Address']."</td><td>".$ro['Salary']."</td><td>".$ro['Department']."</td><td>".$ro['Gender']. "</td></tr>";
 }
}
else{
	echo"Sorry Their is no any record of Teachers";

}
?>

</table><br>
<center><button><a href="updateteacher.php" style="text-decoration: none;">Update Records</a></button>
<button><a href="addteacher.php" style="text-decoration: none;">Add Records</a></button>
</center>




<br><br><br>






<h1 align="center"> Records Of Students </h1>

<table>

	<?php
require("dbconnect.php");

$sqll="SELECT * FROM balak";
$res=mysqli_query($connectivity,$sqll);

if ($res->num_rows > 0){
		echo "<tr><th>ID</th><th>Firstname</th><th>Last Name</th><th>Username</th><th>Password</th><th>Contact</th><th>Address</th><th>Course Type</th><th>Gender</th></tr>";

while($ro=mysqli_fetch_assoc($res)){


	echo "<tr><td>".$ro['ID']."</td><td>".$ro['firstname']."</td><td>".$ro['lastname']."</td><td>".$ro['Uname']."</td><td>".$ro['Pwd']."</td><td>".$ro['Contact']."</td><td>".$ro['Address']."</td><td>".$ro['Course_Type']."</td><td>".$ro['Gender']. "</td></tr>";
 }
}
else{
	echo"Sorry Their is no any record of Students";

}
?>
</table><br>
<center><button><a href="updatestudent.php" style="text-decoration: none;">Update Records</a></button>
<button><a href="addstudent.php" style="text-decoration: none;">Add Records</a></button>
</center>
<br><Br>
<center>
<button  name="logout"><a href="mainlogin.php" style="text-decoration: none;">Logout</button>
</center>