<?php
require("dbconnect.php");
if(isset($_POST['submit'])){
$sqll = "UPDATE teacher SET firstname='$_POST[firstname]' , lastname ='$_POST[lastname]', username = '$_POST[username]' , password = '$_POST[Password]' , Contact = '$_POST[Contact]' ,Address = '$_POST[Address]' ,Salary = '$_POST[Salary]' , Department = '$_POST[Department]' ,Gender = '$_POST[Gender]' WHERE ID='$_POST[id]'";



if (mysqli_query($connectivity,$sqll)) {
	
	header("refresh:1; url=updateteacher.php");

}
else{
echo "Sorry your record is not Updated";

}
}
else{
	$sqll = "DELETE FROM teacher WHERE ID='$_POST[id]'";
	if (mysqli_query($connectivity,$sqll)) {
	
	header("refresh:1; url=updateteacher.php");

}
else{
echo "Sorry your record is not deleted";

}
}
?>