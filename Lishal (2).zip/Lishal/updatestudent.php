<body>
	<?php

		require("dbconnect.php");
		$sqll="SELECT * FROM balak";
		$res=mysqli_query($connectivity,$sqll);

	?>
	<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Username</th>
			<th>Password</th>
			<th>Contact</th>
			<th>Address</th>
			<th>Course Type</th>
			<th>Gender</th>
		</tr>
		<?php

			while ($row = mysqli_fetch_assoc($res)) {
				echo "<tr><form action =upstudent.php method=post></tr>";
				echo"<td><input type = text name=firstname value='".$row["firstname"]."'></td>";
				echo"<td><input type = text name=lastname value='".$row["lastname"]."'></td>";
				echo"<td><input type = text name=username value='".$row["Uname"]."'></td>";
				echo"<td><input type = text name=Password value='".$row["Pwd"]."'></td>";
				echo"<td><input type = text name=Contact value='".$row["Contact"]."'></td>";
				echo"<td><input type = text name=Address value='".$row["Address"]."'></td>";
				echo"<td><input type = text name=Ctype value='".$row["Course_Type"]."'></td>";
				echo"<td><input type = text name=Gender value='".$row["Gender"]."'></td>";
				echo"<input type =hidden name=id value='".$row['ID']."'>";
				echo "<td><input type=submit name=submit value=SUBMIT>";
				echo "<td><input type=submit name=delete value=DELETE>";
				echo "</form></tr>";
			}

			


		?>

	</table>
		<br>
	<Br>
	<button><a href="admin.php" style="text-decoration: none;">Back to Admin page </a></button>