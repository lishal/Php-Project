<?php
session_start();
require('dbconnect.php');
if($_SESSION["user"]==true)
{
	
}
else{
	header("location:mainlogin.php");
}
?>

<?php
$user=$_SESSION['user'];
$query="SELECT * FROM teacher where username = '$user'";
$res=mysqli_query($connectivity,$query);
$ro=mysqli_fetch_assoc($res);


?>

<h1 align="center"><?php echo"Welcome"." ".$_SESSION['user'];?></h1><br><Br>
<center>
<table border="2">
	<tr>
	<th>Id</th>
	<td><?php echo $ro['ID'];?></td>
	</tr>
	<tr>
	<th>First Name</th>
	<td><?php echo $ro['firstname'];?></td>
	</tr>
	<tr>
	<th>Last Name</th>
	<td><?php echo $ro['lastname'];?></td>
	</tr>
	<tr>
	<th>Username</th>
	<td><?php echo $ro['username'];?></td>
	</tr>
	<tr>
	<th>Contact</th>
	<td><?php echo $ro['Contact'];?></td>
	</tr>
	<tr>
	<th>Address</th>
	<td><?php echo $ro['Address'];?></td>
	</tr>
	<tr>
	<th>Salary</th>
	<td><?php echo $ro['Salary'];?></td>
	</tr>
	<tr>
	<th>Department</th>
	<td><?php echo $ro['Department'];?></td>
	</tr>
	<tr>
	<th>Gender</th>
	<td><?php echo $ro['Gender'];?></td>
	</tr>
</table>
<?php
$uploadDirectory="/Image/";
$query1="SELECT Photo FROM teacher where username = '$user'";

$res1=mysqli_query($connectivity,$query1);
$ro1=mysqli_fetch_assoc($res1);

$Photo=$ro1['Photo'];

$url="http://localhost/Php Project work/Lishal";
?>
<img src="<?=$url.$uploadDirectory.$Photo; ?>" style="width: 200px;height: auto; margin-left: 400px; margin-top: -250px;">
	


<br>
<a href="teacherpwchange.php">Change your password</a>
<br><br>
<a href="mainlogin.php">Logout</a>
</center>
