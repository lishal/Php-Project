<?php
$hostname="localhost";
$username="root";
$password="";
$connectivity=mysqli_connect($hostname,$username,$password,"love"); 
?>