<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Create database
$sql = "CREATE DATABASE love";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

$conn->close();
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "love";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// sql to create table
$sql = "CREATE TABLE teacher (
ID BIGINT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
username VARCHAR(50) UNIQUE NOT NULL,
password VARCHAR(30) NOT NULL,
Contact BIGINT(12) NOT NULL,
Address VARCHAR(32)NOT NULL,
Salary INT(9)NOT NULL,
Department VARCHAR(20)NOT NULL,
Gender VARCHAR(20)NOT NULL,
Photo VARBINARY(6000)NOT NULL

)";

if ($conn->query($sql) === TRUE) {
    echo "Teacher created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "love";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "CREATE TABLE balak (
ID BIGINT(10)  AUTO_INCREMENT PRIMARY KEY, 
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
Uname VARCHAR(50) UNIQUE NOT NULL,
Pwd VARCHAR(30) NOT NULL,
Contact BIGINT(12) NOT NULL,
Address VARCHAR(32)NOT NULL,
Course_Type VARCHAR(20)NOT NULL,
Gender VARCHAR(20)NOT NULL,
Photo VARBINARY(6000)NOT NULL

)";

if ($conn->query($sql) === TRUE) {
    echo "Balak created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "love";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "CREATE TABLE mainlogin (
ID BIGINT(100)  AUTO_INCREMENT PRIMARY KEY, 
username VARCHAR(32) NOT NULL,
password VARCHAR(32) NOT NULL,
type VARCHAR(10) NOT NULL

)";

if ($conn->query($sql) === TRUE) {
    echo "Main Login created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>