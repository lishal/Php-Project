<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		
	body
	{
	margin:0;
	padding:0;
	font-family:sans-serif;
	background: url(web.jpg);
	background-size:cover;
	}
	form {
	  float: right;
	  font-size: 20px;
	  margin-top: 27px;
	  margin-right: 10px;
	  height: 20px;
	}

	.loginBox{
  position: absolute;
  top: 50%;
  left: 60%;
  transform:translate(-50%,-50%); 
  width: 340px;
  height: 450px;
  padding: 10px 20px;
  box-sizing: border-box;
  background: rgba(0,0,0,.3);
  color:#ffffff; 
 
}

.loginBox p
{
  margin: 03px;
  padding: 03px;
  font-weight: bold;
  color:#ffffff;
}
.loginBox input
{
  width: 100%;
  margin-bottom: 20px;
}
.loginBox input[type="text"],
.loginBox input[type="password"]
{
  border: none;
  border-bottom: 1px solid #fff;
  border-radius: 0px;
  background: transparent;
  outline: none;
  height: 40px;
  color: #ffffff;
  font-size: 16px;


}
::placeholder
{
  color: rgba(255,255,255,.5);
}
.loginBox input[type="submit"]
{
  border: none;
  outline: none;
  height: 40px;
  color:#fff;
  font-size: 16px;
  background: gold;
  border-radius: 20px;
}
.loginBox input[type="submit"]:hover
{
  background: lightgreen;
  color: #262626;
}
.loginBox a
{
  margin:0px;
  color: black;
  font-size: 18px;
  font-weight: bold;
}
.loginBox a:hover
{
  background: yellow;
  color: #262626;
}

select{
	margin:10px;
	padding: 10px;
	background:white;
  color:black;
  border: none;
  



	</style>
</head>
<body>
	<marquee behavior="alternate"><h1 style="color: white">Welcome to Islington College</h1></marquee>
	<form name="login" method="POST" action="controlmain.php">
	<div class="loginBox">
	<center><p>Login Here</p></center>
	<p style="color: red; font-size:18px;">Invalid Username and Password</p>
	<p>Email:</p>
	<input type="text" name="username"placeholder="Enter Email Address">
	<p>Password:</p>
	<input type="password" name="password"placeholder="Enter Your Password">
	Type:<select name="type"><option value="Admin" name="Admin">Admin</option>
<option value="Teacher" name="Teacher">Teacher</option>
<option value="Student" name="Student">Student</option>	
</select>
<input type="Submit" name="submit" value="Login">

<br>
<button style="background: none; border-radius:20px;"  name="signup">	<a href="register.php" style="text-decoration: none;">Sign Up For Teacher</a></button>
<button style="background: none; border-radius: 20px;" name="register"><a href="register1.php" style="text-decoration: none;">Sign Up For Student</a></button>
</form>
</body>
</html>
