<?php
require("dbconnect.php");
session_start();
$username=$_POST['username'];
$password=$_POST['password'];
$_SESSION['user']=$username;
$_SESSION['pwd']=$password;

$type=$_POST['type'];

if(isset($_POST['submit'])){


	$sql="INSERT INTO mainlogin (username,password,type) VALUES ('$username','$password','$type')";
	$sqll=" SELECT * FROM mainlogin where type='$type'";
	$result=mysqli_query($connectivity,$sqll);
	$row=mysqli_fetch_assoc($result);

	if (!mysqli_query($connectivity,$sql))
	{
		echo"failed!";
		
	}
	else
	{

		if($row['type']=="Admin"){
			if ($username=="admin" and $password=="admin") {
				header("location:admin.php");
				exit();
			}
		}






		elseif ($row['type']=="Teacher") {
				
			if(isset($_POST['submit']))
			{

			$s="SELECT * FROM teacher where username = '$username' and password='$password'";
			$res=mysqli_query($connectivity,$s);
			$ro=mysqli_fetch_assoc($res);

			if($ro==true)
			{
				$_SESSION['user']=$username;
				$_SESSION['pwd']=$password;
				header("location:teachersuccess.php");
				exit();
			}

			}
			
			}



		elseif ($row['type']=="Student") {
			if(isset($_POST['submit']))
				{


					$sql=" SELECT * FROM balak where Uname = '$username' and Pwd ='$password'";
					$result=mysqli_query($connectivity,$sql);
					$row=mysqli_fetch_assoc($result);

					if($row==true)
					{
						$_SESSION['user']=$username;
						$_SESSION['pwd']=$password;
						header("location:studentsuccess.php");
						exit();
					}
				
				}
		}


		header("location:invalid.php");


	}
		
		

	
	}

		


	
	
	
?>
<br><br>
